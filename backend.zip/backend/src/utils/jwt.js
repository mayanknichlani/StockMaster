const jwt = require('jsonwebtoken');
require('dotenv').config();
const JWT_SECRET = process.env.JWT_SECRET;
// const JWT_EXPIRE = process.env.JWT_EXPIRE;



const generateToken = (id, role) => {
    console.log("JWT_SECRET:", process.env.JWT_SECRET);
  return jwt.sign(
    { id, role },
    process.env.JWT_SECRET,   // THIS WAS UNDEFINED
    { expiresIn: '7d' }
  );
};

const verifyToken = (token) => {
  return jwt.verify(token, JWT_SECRET);
};

module.exports = { generateToken, verifyToken };